module.exports.calcular = (req, res, next) => {
  let num = req.query.numero;
  let divisor = req.query.divisor;
  try {
    if (num == null) {
      throw new Error("Parâmetro Numero não fornecido");
    }
    if (divisor == null) {
      throw new Error("Parâmetro Divisor não fornecido");
    }
    
  } catch (error) {
    next(error)
  }
  function eDivisivel() {
    num % divisor == 0 ? true : false;
  }
  eDivisivel();
  let resultadoFunc = num % divisor == 0 ? "é divisivel" : "Não é divisivel";

  res.render("ex5", {resultadoFunc})
};


module.exports.mostrar = (req, res) => {
    let resultadoFunc = ""
    res.render("ex5", {resultadoFunc})

};
