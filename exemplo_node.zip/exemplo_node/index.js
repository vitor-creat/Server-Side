const app = require('./src/config/custom-express')

app.listen(3000, () => {
  console.log("Servidor Rodando no localhost:3000");
});

